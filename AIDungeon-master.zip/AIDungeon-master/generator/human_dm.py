from story.utils import *


class HumanDM:
    def generate(self, prompt, options=None, seed=None):
        return input()
